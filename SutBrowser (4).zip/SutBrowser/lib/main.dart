import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  if (Platform.isAndroid) {
    await InAppWebViewController.setWebContentsDebuggingEnabled(false);
  }

  runApp(const SutBrowserApp());
}

// ── Cores ──────────────────────────────────────────────────────────────────
const kBg      = Color(0xFF0F0F13);
const kBar     = Color(0xFF16161C);
const kSurface = Color(0xFF1E1E26);
const kBorder  = Color(0xFF2C2C3A);
const kAccent  = Color(0xFF00D4AA);
const kAccent2 = Color(0xFF7C6AFF);
const kText    = Color(0xFFE8E8F4);
const kMuted   = Color(0xFF5A5A78);
const kDanger  = Color(0xFFFF4757);

const kIncogBg  = Color(0xFF0D0015);
const kIncogBar = Color(0xFF130020);
const kIncogAcc = Color(0xFFB94FFF);

// ── Mecanismos de busca ────────────────────────────────────────────────────
const engines = {
  'Google':     'https://www.google.com/search?q=',
  'Bing':       'https://www.bing.com/search?q=',
  'DuckDuckGo': 'https://duckduckgo.com/?q=',
  'Ecosia':     'https://www.ecosia.org/search?q=',
};

class SutBrowserApp extends StatelessWidget {
  const SutBrowserApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SUT Browser',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: kBg,
        colorScheme: const ColorScheme.dark(primary: kAccent),
      ),
      home: const BrowserScreen(),
    );
  }
}

// ── Modelo de aba ─────────────────────────────────────────────────────────
class BrowserTab {
  String title;
  String url;
  String favicon;
  InAppWebViewController? controller;
  bool isLoading;

  BrowserTab({
    this.title = 'Nova aba',
    this.url = 'https://www.google.com',
    this.favicon = '🌐',
    this.controller,
    this.isLoading = false,
  });
}

// ── Tela principal ────────────────────────────────────────────────────────
class BrowserScreen extends StatefulWidget {
  final bool incognito;
  const BrowserScreen({super.key, this.incognito = false});

  @override
  State<BrowserScreen> createState() => _BrowserScreenState();
}

class _BrowserScreenState extends State<BrowserScreen> with TickerProviderStateMixin {
  final List<BrowserTab> _tabs = [];
  int _activeTab = 0;
  bool _showTabs = false;
  bool _canGoBack = false;
  bool _canGoFwd = false;
  String _currentUrl = '';
  bool _isLoading = false;
  String _engine = 'Google';
  late TextEditingController _urlController;
  late AnimationController _tabAnimCtrl;

  bool get isIncognito => widget.incognito;
  Color get accent => isIncognito ? kIncogAcc : kAccent;
  Color get barColor => isIncognito ? kIncogBar : kBar;
  Color get bgColor => isIncognito ? kIncogBg : kBg;

  @override
  void initState() {
    super.initState();
    _urlController = TextEditingController();
    _tabAnimCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 200));
    _loadEngine();
    _addTab('https://www.google.com');
  }

  @override
  void dispose() {
    _urlController.dispose();
    _tabAnimCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadEngine() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() => _engine = prefs.getString('engine') ?? 'Google');
  }

  Future<void> _saveEngine(String e) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('engine', e);
    setState(() => _engine = e);
  }

  // ── Abas ────────────────────────────────────────────────────────────────
  void _addTab(String url) {
    setState(() {
      _tabs.add(BrowserTab(url: url));
      _activeTab = _tabs.length - 1;
      _currentUrl = url;
      _urlController.text = url;
      _showTabs = false;
    });
  }

  void _closeTab(int i) {
    setState(() {
      _tabs.removeAt(i);
      if (_tabs.isEmpty) {
        _addTab('https://www.google.com');
        return;
      }
      _activeTab = i.clamp(0, _tabs.length - 1);
      _syncUrl();
    });
  }

  void _switchTab(int i) {
    setState(() {
      _activeTab = i;
      _showTabs = false;
      _syncUrl();
    });
  }

  void _syncUrl() {
    if (_tabs.isEmpty) return;
    _currentUrl = _tabs[_activeTab].url;
    _urlController.text = _currentUrl;
  }

  // ── Navegação ────────────────────────────────────────────────────────────
  String _buildUrl(String input) {
    input = input.trim();
    if (input.startsWith('http://') || input.startsWith('https://') || input.startsWith('file://')) {
      return input;
    }
    final domainRegex = RegExp(r'^[\w-]+\.[a-z]{2,}(\/.*)?$');
    if (domainRegex.hasMatch(input)) return 'https://$input';
    final base = engines[_engine] ?? engines['Google']!;
    return '$base${Uri.encodeComponent(input)}';
  }

  void _navigate(String input) {
    final url = _buildUrl(input);
    _tabs[_activeTab].controller?.loadUrl(
      urlRequest: URLRequest(url: WebUri(url)),
    );
    setState(() {
      _currentUrl = url;
      _urlController.text = url;
    });
    FocusScope.of(context).unfocus();
  }

  // ── UI ───────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgColor,
      body: SafeArea(
        child: Column(
          children: [
            _buildTopBar(),
            _buildNavBar(),
            Expanded(
              child: Stack(
                children: [
                  // WebViews (uma por aba, escondendo as inativas)
                  ...List.generate(_tabs.length, (i) {
                    return Offstage(
                      offstage: i != _activeTab,
                      child: _buildWebView(i),
                    );
                  }),
                  // Overlay de abas
                  if (_showTabs) _buildTabsOverlay(),
                ],
              ),
            ),
            _buildBottomBar(),
          ],
        ),
      ),
    );
  }

  // ── Barra do topo (desktop-style) ─────────────────────────────────────
  Widget _buildTopBar() {
    return Container(
      height: 44,
      color: barColor,
      child: Row(
        children: [
          const SizedBox(width: 10),
          // Logo
          Image.asset('assets/logo.png', height: 26, width: 26, fit: BoxFit.contain),
          const SizedBox(width: 8),
          Text(
            isIncognito ? 'SUT Browser  👤' : 'SUT Browser',
            style: TextStyle(
              color: accent, fontWeight: FontWeight.bold, fontSize: 13,
            ),
          ),
          const Spacer(),
          // Abas count
          _topBtn(
            '${_tabs.length} aba${_tabs.length != 1 ? 's' : ''}',
            () => setState(() => _showTabs = !_showTabs),
            isText: true,
          ),
          _topBtn('⊕', () => _addTab('https://www.google.com')),
          _topBtn('⋮', _showOptionsMenu),
        ],
      ),
    );
  }

  Widget _topBtn(String label, VoidCallback onTap, {bool isText = false}) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        margin: const EdgeInsets.symmetric(horizontal: 2, vertical: 6),
        decoration: BoxDecoration(
          color: kSurface,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text(label, style: const TextStyle(color: kText, fontSize: 13)),
      ),
    );
  }

  // ── Barra de URL ──────────────────────────────────────────────────────
  Widget _buildNavBar() {
    return Container(
      height: 52,
      color: barColor,
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      child: Row(
        children: [
          _navBtn(_canGoBack ? '←' : '←', _canGoBack ? () => _tabs[_activeTab].controller?.goBack() : null),
          _navBtn('→', _canGoFwd ? () => _tabs[_activeTab].controller?.goForward() : null),
          _navBtn('↺', () => _tabs[_activeTab].controller?.reload()),

          const SizedBox(width: 4),

          // URL bar
          Expanded(
            child: GestureDetector(
              onTap: () => _urlController.selection = TextSelection(
                baseOffset: 0, extentOffset: _urlController.text.length,
              ),
              child: Container(
                height: 36,
                decoration: BoxDecoration(
                  color: kSurface,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: kBorder),
                ),
                child: Row(
                  children: [
                    const SizedBox(width: 10),
                    Icon(
                      _currentUrl.startsWith('https') ? Icons.lock : Icons.lock_open,
                      size: 14,
                      color: _currentUrl.startsWith('https') ? kAccent : kMuted,
                    ),
                    const SizedBox(width: 6),
                    Expanded(
                      child: TextField(
                        controller: _urlController,
                        style: const TextStyle(color: kText, fontSize: 12, fontFamily: 'monospace'),
                        decoration: const InputDecoration(
                          border: InputBorder.none,
                          isDense: true,
                          hintText: 'Pesquise ou digite um endereço...',
                          hintStyle: TextStyle(color: kMuted, fontSize: 12),
                        ),
                        onSubmitted: _navigate,
                        textInputAction: TextInputAction.go,
                      ),
                    ),
                    if (_isLoading)
                      const SizedBox(
                        width: 16, height: 16,
                        child: CircularProgressIndicator(strokeWidth: 2, color: kAccent),
                      ),
                    const SizedBox(width: 8),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _navBtn(String icon, VoidCallback? onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        width: 34, height: 34,
        alignment: Alignment.center,
        child: Text(
          icon,
          style: TextStyle(
            fontSize: 18,
            color: onTap != null ? kText : kMuted,
          ),
        ),
      ),
    );
  }

  // ── WebView ───────────────────────────────────────────────────────────
  Widget _buildWebView(int i) {
    final tab = _tabs[i];
    return InAppWebView(
      key: ValueKey('tab_$i'),
      initialUrlRequest: URLRequest(url: WebUri(tab.url)),
      initialSettings: InAppWebViewSettings(
        javaScriptEnabled: true,
        domStorageEnabled: !isIncognito,
        databaseEnabled: !isIncognito,
        cacheEnabled: !isIncognito,
        incognito: isIncognito,
        supportZoom: true,
        useHybridComposition: true,
        allowsInlineMediaPlayback: true,
        mediaPlaybackRequiresUserGesture: false,
        userAgent:
            'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
      ),
      onWebViewCreated: (ctrl) {
        tab.controller = ctrl;
      },
      onLoadStart: (ctrl, url) {
        if (i != _activeTab) return;
        setState(() {
          _isLoading = true;
          _currentUrl = url?.toString() ?? '';
          _urlController.text = _currentUrl;
        });
      },
      onLoadStop: (ctrl, url) async {
        if (i != _activeTab) return;
        final title = await ctrl.getTitle() ?? 'Nova aba';
        final canBack = await ctrl.canGoBack();
        final canFwd  = await ctrl.canGoForward();
        setState(() {
          _isLoading = false;
          _tabs[i].title = title;
          _tabs[i].url   = url?.toString() ?? _tabs[i].url;
          _currentUrl    = _tabs[i].url;
          _urlController.text = _currentUrl;
          _canGoBack = canBack;
          _canGoFwd  = canFwd;
        });
      },
      onTitleChanged: (ctrl, title) {
        setState(() => _tabs[i].title = title ?? 'Nova aba');
      },
      onReceivedError: (ctrl, req, err) {
        if (i == _activeTab) setState(() => _isLoading = false);
      },
    );
  }

  // ── Overlay de abas ───────────────────────────────────────────────────
  Widget _buildTabsOverlay() {
    return Container(
      color: bgColor,
      child: Column(
        children: [
          // Header
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            color: barColor,
            child: Row(
              children: [
                Text('${_tabs.length} aba${_tabs.length != 1 ? 's' : ''}',
                  style: TextStyle(color: accent, fontWeight: FontWeight.bold, fontSize: 15)),
                const Spacer(),
                ElevatedButton.icon(
                  onPressed: () => _addTab('https://www.google.com'),
                  icon: const Icon(Icons.add, size: 16),
                  label: const Text('Nova aba'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: accent,
                    foregroundColor: Colors.black,
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    textStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
          ),
          // Grid de abas
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(12),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 1.3,
              ),
              itemCount: _tabs.length,
              itemBuilder: (ctx, i) {
                final tab = _tabs[i];
                final isActive = i == _activeTab;
                return GestureDetector(
                  onTap: () => _switchTab(i),
                  child: Container(
                    decoration: BoxDecoration(
                      color: kSurface,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: isActive ? accent : kBorder,
                        width: isActive ? 2 : 1,
                      ),
                    ),
                    child: Column(
                      children: [
                        // Barra da aba
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                          decoration: BoxDecoration(
                            color: isActive ? accent.withOpacity(0.15) : kBar,
                            borderRadius: const BorderRadius.vertical(top: Radius.circular(11)),
                          ),
                          child: Row(
                            children: [
                              Expanded(
                                child: Text(tab.title,
                                  style: const TextStyle(fontSize: 11, color: kText),
                                  maxLines: 1, overflow: TextOverflow.ellipsis),
                              ),
                              GestureDetector(
                                onTap: () => _closeTab(i),
                                child: const Icon(Icons.close, size: 14, color: kMuted),
                              ),
                            ],
                          ),
                        ),
                        // Preview URL
                        Expanded(
                          child: Center(
                            child: Padding(
                              padding: const EdgeInsets.all(8),
                              child: Text(
                                tab.url.replaceAll('https://', '').replaceAll('http://', ''),
                                style: const TextStyle(fontSize: 10, color: kMuted),
                                maxLines: 3, overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.center,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  // ── Barra inferior (mobile) ────────────────────────────────────────────
  Widget _buildBottomBar() {
    return Container(
      height: 50,
      color: barColor,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _bottomBtn(Icons.arrow_back_ios_new, _canGoBack ? () => _tabs[_activeTab].controller?.goBack() : null),
          _bottomBtn(Icons.arrow_forward_ios, _canGoFwd ? () => _tabs[_activeTab].controller?.goForward() : null),
          _bottomBtn(Icons.refresh, () => _tabs[_activeTab].controller?.reload()),
          _bottomBtn(Icons.home_outlined, () => _navigate('https://www.google.com')),
          _bottomBtn(Icons.tab_outlined, () => setState(() => _showTabs = !_showTabs)),
          _bottomBtn(Icons.more_vert, _showOptionsMenu),
        ],
      ),
    );
  }

  Widget _bottomBtn(IconData icon, VoidCallback? onTap) {
    return IconButton(
      icon: Icon(icon, size: 22),
      color: onTap != null ? kText : kMuted,
      onPressed: onTap,
      splashRadius: 20,
    );
  }

  // ── Menu de opções ────────────────────────────────────────────────────
  void _showOptionsMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: kSurface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => _OptionsSheet(
        engine: _engine,
        onEngineChange: (e) { _saveEngine(e); Navigator.pop(ctx); },
        onNewIncognito: () {
          Navigator.pop(ctx);
          Navigator.push(context, MaterialPageRoute(
            builder: (_) => const BrowserScreen(incognito: true),
          ));
        },
        onClose: () => Navigator.pop(ctx),
      ),
    );
  }
}

// ── Modal de opções ────────────────────────────────────────────────────────
class _OptionsSheet extends StatelessWidget {
  final String engine;
  final void Function(String) onEngineChange;
  final VoidCallback onNewIncognito;
  final VoidCallback onClose;

  const _OptionsSheet({
    required this.engine,
    required this.onEngineChange,
    required this.onNewIncognito,
    required this.onClose,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Center(
            child: Text('Opções', style: TextStyle(color: kText, fontSize: 16, fontWeight: FontWeight.bold)),
          ),
          const SizedBox(height: 20),

          // Mecanismo de busca
          const Text('Mecanismo de busca', style: TextStyle(color: kMuted, fontSize: 12)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8, runSpacing: 8,
            children: engines.keys.map((e) {
              final selected = e == engine;
              return GestureDetector(
                onTap: () => onEngineChange(e),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(
                    color: selected ? kAccent : kBar,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: selected ? kAccent : kBorder),
                  ),
                  child: Text(e,
                    style: TextStyle(
                      color: selected ? Colors.black : kText,
                      fontWeight: selected ? FontWeight.bold : FontWeight.normal,
                      fontSize: 13,
                    ),
                  ),
                ),
              );
            }).toList(),
          ),

          const SizedBox(height: 20),
          const Divider(color: kBorder),
          const SizedBox(height: 8),

          // Janela anônima
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Text('👤', style: TextStyle(fontSize: 22)),
            title: const Text('Nova janela anônima', style: TextStyle(color: kText)),
            subtitle: const Text('Sem histórico ou cookies', style: TextStyle(color: kMuted, fontSize: 12)),
            onTap: onNewIncognito,
          ),

          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Text('✕', style: TextStyle(fontSize: 18, color: kDanger)),
            title: const Text('Fechar', style: TextStyle(color: kText)),
            onTap: onClose,
          ),
        ],
      ),
    );
  }
}
